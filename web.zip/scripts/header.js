class Header {
	static transition() {
		// Code to transition ...
	}
};
